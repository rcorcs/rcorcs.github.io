
import java.util.List;
import java.util.ArrayList;

public class Coberturas {
	public static List<Integer> vertices(Grafo g){
		//FAZER
		return new ArrayList<Integer>();
	}
}
