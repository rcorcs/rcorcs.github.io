/*
 * Disciplina: Algoritmos em grafos
 * Professor: Rodrigo Caetano Rocha
 * Topico: Estruturas de Dados de Digrafos;
 *         Lista de adjacencias.
 */

import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * Classe que implementa um grafo direcionado, ou digrafo.
 */
public class ListaGrafo extends Grafo {
	private int n;
	private List<Integer> []adj;

	public ListaGrafo(int n){
		this.n = n;
		this.adj = (List<Integer>[])new List[n];
		for(int u = 0; u<this.n; u++){
			this.adj[u] = new ArrayList<Integer>();
		}
	}

   /**
    * Adiciona uma nova aresta entre os vértices u e v.
    */
	public void adicionaAresta(int u, int v){
		this.adj[u].add(new Integer(v));
		if(u!=v) this.adj[v].add(new Integer(u));
	}

   /**
    * Remove uma nova aresta entre os vertices u e v, caso a mesma exista.
    */
	public void removeAresta(int u, int v){
		this.adj[u].remove(new Integer(v)); //remove uma ocorrencia da aresta de u para v.
	}

   /**
    * Verifica se existe uma aresta entre os vertices u e v.
    * @return true caso existir a aresta {u,v} ou false caso contrario.
    */
	public boolean existeAresta(int u, int v){
		return this.adj[u].contains(new Integer(v));
	}

	/**
	 * Obtem o numero de vertices do grafo.
    * @return o numero de vertices.
	 */
	public int numVertices(){
		return this.n;
	}

	/**
	 * Obtem o numero de arestas do grafo.
    * @return o numero de arestas do grafo.
	 */
	public int numArestas(){
		int arestas = 0;
		for(int u = 0; u<numVertices(); u++){
			for(Integer v: this.adj[u]){
				if(v.intValue()>=u){
					arestas++;
				}
			}
		}
		return arestas;
	}
	
	/**
	 * Obtem os vizinhos de um dado vertice u.
    * @return conjunto de vizinhos do vertice u.
	 */
	public List<Integer> vizinhos(int u){
		return this.adj[u];
	}

	/**
	 * Calcula o grau do vertice u.
    * O grau de um vertice u representa o numero de arestas que possuem u como um de seus vertices.
    * @return grau do vertice u.
	 */
	public int grau(int u){
		return adj[u].size();
	}
}
