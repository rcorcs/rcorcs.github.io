/*
 * Disciplina: Algoritmos em grafos
 * Professor: Rodrigo Caetano Rocha
 * Topico: Estruturas de Dados de Digrafos;
 *         Matriz de adjacencias.
 */
import java.util.List;
import java.util.ArrayList;

/**
 * Classe que implementa um grafo direcionado, ou digrafo.
 */
public class MatrizGrafo extends Grafo {
	private int n;
	private int [][]adj;

	public MatrizGrafo(int n){
		this.n = n;
		this.adj = new int[n][n];
	}

   /**
    * Adiciona uma nova aresta entre os vértices u e v.
    */
	public void adicionaAresta(int u, int v){
		this.adj[u][v] = 1;
		if(u!=v) this.adj[v][u] = 1;
	}

   /**
    * Remove uma nova aresta entre os vertices u e v, caso a mesma exista.
    */
	public void removeAresta(int u, int v){
		this.adj[u][v] = 0;
		this.adj[v][u] = 0;
	}

   /**
    * Verifica se existe uma aresta entre os vertices u e v.
    * @return true caso existir a aresta {u,v} ou false caso contrario.
    */
	public boolean existeAresta(int u, int v){
		return this.adj[u][v]!=0;
	}

	/**
	 * Obtem o numero de vertices do grafo.
    * @return o numero de vertices.
	 */
	public int numVertices(){
		return this.n;
	}

	/**
	 * Obtem o numero de arestas do grafo.
    * @return o numero de arestas do grafo.
	 */
	public int numArestas(){
		int arestas = 0;
		for(int u = 0; u<numVertices(); u++){
			for(int v = u; v<numVertices(); v++){
				if(existeAresta(u,v)){
					arestas++;
				}
			}
		}
		return arestas;
	}
	
	/**
	 * Obtem os vizinhos de um dado vertice u.
    * @return conjunto de vizinhos do vertice u.
	 */
	public List<Integer> vizinhos(int u){
		List<Integer> resp = new ArrayList<Integer>();
		for(int v = 0; v<numVertices(); v++){
			if(existeAresta(u,v)){
				resp.add(v);
			}
		}
		return resp;
	}

	/**
	 * Calcula o grau do vertice u.
    * O grau de um vertice u representa o numero de arestas que possuem u como um de seus vertices.
    * @return grau do vertice u.
	 */
	public int grau(int u){
		int count = 0;
		for(int v = 0; v<numVertices(); v++){
			if(existeAresta(u,v)){
				count++;
			}
		}
		return count;
	}
}
