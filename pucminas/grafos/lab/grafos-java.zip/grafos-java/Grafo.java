/*
 * Disciplina: Algoritmos em grafos
 * Professor: Rodrigo Caetano Rocha
 * Topico: Estruturas de Dados de Digrafos.
 */
import java.util.List;

/**
 * Classe que implementa um grafo direcionado, ou digrafo.
 */
public abstract class Grafo {

   /**
    * Adiciona uma nova aresta entre os vértices u e v.
    */
	public abstract void adicionaAresta(int u, int v);

   /**
    * Remove uma nova aresta entre os vertices u e v, caso a mesma exista.
    */
	public abstract void removeAresta(int u, int v);

   /**
    * Verifica se existe uma aresta entre os vertices u e v.
    * @return true caso existir a aresta {u,v} ou false caso contrario.
    */
	public abstract boolean existeAresta(int u, int v);

	/**
	 * Obtem o numero de vertices do grafo.
    * @return o numero de vertices.
	 */
	public abstract int numVertices();

	/**
	 * Obtem o numero de arestas do grafo.
    * @return o numero de arestas do grafo.
	 */
	public abstract int numArestas();

	/**
	 * Obtem os vizinhos de um dado vertice u.
    * @return conjunto de vizinhos do vertice u.
	 */
	public abstract List<Integer> vizinhos(int u);

	/**
	 * Calcula o grau do vertice u.
    * O grau de um vertice u representa o numero de arestas que possuem u como um de seus vertices.
    * @return grau do vertice u.
	 */
	public abstract int grau(int u);

}
