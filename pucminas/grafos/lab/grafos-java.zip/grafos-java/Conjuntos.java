
import java.util.List;
import java.util.ArrayList;

public class Conjuntos {
	public static List<Integer> dominante(Grafo g){
		//FAZER
		return new ArrayList<Integer>();
	}

	public static boolean temVertice(boolean []vertices){
		for(int i = 0; i<vertices.length; i++)
			if(vertices[i]==true) return true;
		return false;
	}

	public static List<Integer> independente(Grafo g){
		boolean []vertices = new boolean[g.numVertices()];
		List<Integer> ci = new ArrayList<Integer>();

		for(int i = 0; i<vertices.length; i++)
			vertices[i]=true;

		while(temVertice(vertices)){
			int minv = -1;
			int ming = -1;
			for(int v = 1; v<g.numVertices(); v++){
				if(vertices[v]==true){
					if(minv<0 || g.grau(v)<ming){
						ming = g.grau(v);
						minv = v;
					}
				}
			}
			ci.add(new Integer(minv));
			vertices[minv] = false;
			for(Integer v: g.vizinhos(minv)){
				vertices[v.intValue()] = false;
			}
		}

		return ci;
	}
}
