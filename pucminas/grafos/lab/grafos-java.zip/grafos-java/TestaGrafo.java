import java.util.List;

public class TestaGrafo{
	
	public static String stringCorreto(int valor, int esperado){
		return (esperado==valor)?"OK":"ERRADO";
	}

	public static String stringCorreto(boolean valor, boolean esperado){
		return (esperado==valor)?"OK":"ERRADO";
	}

	public static void verifica(String texto, int valor, int esperado){
		System.out.printf("%s: %d [%s]\n", texto, valor, stringCorreto(valor,esperado) );
	}

	public static void verifica(String texto, boolean valor, boolean esperado){
		System.out.printf("%s: %b [%s]\n", texto, valor, stringCorreto(valor,esperado) );
	}

	
	public static void testaMatrizGrafo(){
		System.out.println("[Testando MatrizGrafo]");
		Grafo grafo = new MatrizGrafo(6);
		grafo.adicionaAresta(0,1);
		grafo.adicionaAresta(0,3);
		grafo.adicionaAresta(1,4);
		grafo.adicionaAresta(2,4);
		grafo.adicionaAresta(2,5);
		grafo.adicionaAresta(3,1);
		grafo.adicionaAresta(4,3);
		grafo.adicionaAresta(5,5);

		verifica("Numero vertices", grafo.numVertices(), 6);
		verifica("Numero arestas", grafo.numArestas(), 8);

		verifica("Existe aresta 0->1", grafo.existeAresta(0,1), true);
		verifica("Existe aresta 0->3", grafo.existeAresta(0,3), true);
		verifica("Existe aresta 1->4", grafo.existeAresta(1,4), true);
		verifica("Existe aresta 2->4", grafo.existeAresta(2,4), true);
		verifica("Existe aresta 2->5", grafo.existeAresta(2,5), true);
		verifica("Existe aresta 3->1", grafo.existeAresta(3,1), true);
		verifica("Existe aresta 4->3", grafo.existeAresta(4,3), true);
		verifica("Existe aresta 5->5", grafo.existeAresta(5,5), true);

		int arestasExistentes = 0;
		for(int u = 0; u<grafo.numVertices(); u++){
			for(int v = u; v<grafo.numVertices(); v++){
				if(grafo.existeAresta(u,v)){
					arestasExistentes++;
				}
			}
		}
		verifica("Arestas existentes",arestasExistentes,8);

		verifica("Grau do vertice 0", grafo.grau(0), 2);
		verifica("Grau do vertice 1", grafo.grau(1), 3);
		verifica("Grau do vertice 2", grafo.grau(2), 2);
		verifica("Grau do vertice 3", grafo.grau(3), 3);
		verifica("Grau do vertice 4", grafo.grau(4), 3);
		verifica("Grau do vertice 5", grafo.grau(5), 2);

		List<Integer> cobertura = Coberturas.vertices(grafo);
		System.out.print("Cobertura de vertices: ");
		for(Integer v: cobertura){
			System.out.printf("%d ", v);
		}
		System.out.println();

		List<Integer> conjIndependente = Conjuntos.independente(grafo);
		System.out.print("Conjunto independente: ");
		for(Integer v: conjIndependente){
			System.out.printf("%d ", v);
		}
		System.out.println();

		System.out.println("[Concluido MatrizGrafo]");
		System.out.println();
	}

	public static void testaListaGrafo(){
		System.out.println("[Testando ListaGrafo]");
		Grafo grafo = new ListaGrafo(6);
		grafo.adicionaAresta(0,1);
		grafo.adicionaAresta(0,3);
		grafo.adicionaAresta(1,4);
		grafo.adicionaAresta(2,4);
		grafo.adicionaAresta(2,5);
		grafo.adicionaAresta(3,1);
		grafo.adicionaAresta(4,3);
		grafo.adicionaAresta(5,5);

		verifica("Numero vertices", grafo.numVertices(), 6);
		verifica("Numero arestas", grafo.numArestas(), 8);

		verifica("Existe aresta 0->1", grafo.existeAresta(0,1), true);
		verifica("Existe aresta 0->3", grafo.existeAresta(0,3), true);
		verifica("Existe aresta 1->4", grafo.existeAresta(1,4), true);
		verifica("Existe aresta 2->4", grafo.existeAresta(2,4), true);
		verifica("Existe aresta 2->5", grafo.existeAresta(2,5), true);
		verifica("Existe aresta 3->1", grafo.existeAresta(3,1), true);
		verifica("Existe aresta 4->3", grafo.existeAresta(4,3), true);
		verifica("Existe aresta 5->5", grafo.existeAresta(5,5), true);

		int arestasExistentes = 0;
		for(int u = 0; u<grafo.numVertices(); u++){
			for(int v = u; v<grafo.numVertices(); v++){
				if(grafo.existeAresta(u,v)){
					arestasExistentes++;
				}
			}
		}
		verifica("Arestas existentes",arestasExistentes,8);

		verifica("Grau do vertice 0", grafo.grau(0), 2);
		verifica("Grau do vertice 1", grafo.grau(1), 3);
		verifica("Grau do vertice 2", grafo.grau(2), 2);
		verifica("Grau do vertice 3", grafo.grau(3), 3);
		verifica("Grau do vertice 4", grafo.grau(4), 3);
		verifica("Grau do vertice 5", grafo.grau(5), 2);

		List<Integer> cobertura = Coberturas.vertices(grafo);
		System.out.print("Cobertura de vertices: ");
		for(Integer v: cobertura){
			System.out.printf("%d ", v);
		}
		System.out.println();

		List<Integer> conjIndependente = Conjuntos.independente(grafo);
		System.out.print("Conjunto independente: ");
		for(Integer v: conjIndependente){
			System.out.printf("%d ", v);
		}
		System.out.println();

		System.out.println("[Concluido ListaGrafo]");
		System.out.println();
	}

	public static void main(String []args){
		testaMatrizGrafo();
		testaListaGrafo();
	}
}
