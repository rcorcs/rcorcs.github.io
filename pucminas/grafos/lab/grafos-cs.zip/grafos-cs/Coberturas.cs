using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Grafos
{
	public class Coberturas
	{
		public static List<int> vertices(Grafo g){
			//FAZER
			return new List<int>();
		}
	}
}

