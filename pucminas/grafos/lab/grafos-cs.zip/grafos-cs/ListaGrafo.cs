using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Grafos
{

	/**
 * Classe que implementa um grafo direcionado, ou digrafo.
 */
	public class ListaGrafo : Grafo {
		private int n;
		private List<int> []adj;
		
		public ListaGrafo(int n){
			this.n = n;
			this.adj = new List<int>[n];
			for(int u = 0; u<this.n; u++){
				this.adj[u] = new List<int>();
			}
		}
		
		/**
    * Adiciona uma nova aresta entre os vértices u e v.
    */
		public override void adicionaAresta(int u, int v){
			this.adj[u].Add(v);
			if(u!=v) this.adj[v].Add(u);
		}

		/**
    * Remove uma nova aresta entre os vertices u e v, caso a mesma exista.
    */
		public override void removeAresta(int u, int v){
			this.adj[u].Remove(v); //remove uma ocorrencia da aresta de u para v.
		}
		
		/**
    * Verifica se existe uma aresta entre os vertices u e v.
    * @return true caso existir a aresta {u,v} ou false caso contrario.
    */
		public override bool existeAresta(int u, int v){
			return this.adj[u].Contains(v);
		}
		
		/**
	 * Obtem o numero de vertices do grafo.
    * @return o numero de vertices.
	 */
		public override int numVertices(){
			return this.n;
		}
		
		/**
	 * Obtem o numero de arestas do grafo.
    * @return o numero de arestas do grafo.
	 */
		public override int numArestas(){
			int arestas = 0;
			for(int u = 0; u<numVertices(); u++){
				foreach(int v in this.adj[u]){
					if(v>=u){
						arestas++;
					}
				}
			}
			return arestas;
		}
		
		/**
	 * Obtem os vizinhos de um dado vertice u.
    * @return conjunto de vizinhos do vertice u.
	 */
		public override List<int> vizinhos(int u){
			return this.adj[u];
		}
		
		/**
	 * Calcula o grau do vertice u.
    * O grau de um vertice u representa o numero de arestas que possuem u como um de seus vertices.
    * @return grau do vertice u.
	 */
		public override int grau(int u){
			return adj[u].Count;
		}
	}
}

