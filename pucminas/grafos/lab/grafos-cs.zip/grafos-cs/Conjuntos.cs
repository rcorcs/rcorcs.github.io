using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Grafos
{
	public class Conjuntos
	{
		public static List<int> dominante(Grafo g){
			//FAZER
			return new List<int>();
		}
		
		public static bool temVertice(bool []vertices){
			for(int i = 0; i<vertices.Length; i++)
				if(vertices[i]==true) return true;
			return false;
		}
		
		public static List<int> independente(Grafo g){
			bool []vertices = new bool[g.numVertices()];
			List<int> ci = new List<int>();
			
			for(int i = 0; i<vertices.Length; i++)
				vertices[i]=true;
			
			while(temVertice(vertices)){
				int minv = -1;
				int ming = -1;
				for(int v = 1; v<g.numVertices(); v++){
					if(vertices[v]==true){
						if(minv<0 || g.grau(v)<ming){
							ming = g.grau(v);
							minv = v;
						}
					}
				}
				ci.Add(minv);
				vertices[minv] = false;
				foreach(int v in g.vizinhos(minv)){
					vertices[v] = false;
				}
			}
			
			return ci;
		}
	}
}

