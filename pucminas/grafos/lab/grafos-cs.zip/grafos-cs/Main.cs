using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Grafos
{
	class MainClass
	{
		
		public static string stringCorreto(int valor, int esperado){
			return (esperado==valor)?"OK":"ERRADO";
		}
		
		public static string stringCorreto(bool valor, bool esperado){
			return (esperado==valor)?"OK":"ERRADO";
		}
		
		public static void verifica(string texto, int valor, int esperado){
			Console.WriteLine("{0}: {1} [{2}]", texto, valor, stringCorreto(valor, esperado));
		}
		
		public static void verifica(string texto, bool valor, bool esperado){
			Console.WriteLine("{0}: {1} [{2}]", texto, valor, stringCorreto(valor, esperado));
		}
		
		
		public static void testaMatrizGrafo(){
			Console.WriteLine("[Testando MatrizGrafo]");
			Grafo grafo = new MatrizGrafo(6);
			grafo.adicionaAresta(0,1);
			grafo.adicionaAresta(0,3);
			grafo.adicionaAresta(1,4);
			grafo.adicionaAresta(2,4);
			grafo.adicionaAresta(2,5);
			grafo.adicionaAresta(3,1);
			grafo.adicionaAresta(4,3);
			grafo.adicionaAresta(5,5);
			
			verifica("Numero vertices", grafo.numVertices(), 6);
			verifica("Numero arestas", grafo.numArestas(), 8);
			
			verifica("Existe aresta 0->1", grafo.existeAresta(0,1), true);
			verifica("Existe aresta 0->3", grafo.existeAresta(0,3), true);
			verifica("Existe aresta 1->4", grafo.existeAresta(1,4), true);
			verifica("Existe aresta 2->4", grafo.existeAresta(2,4), true);
			verifica("Existe aresta 2->5", grafo.existeAresta(2,5), true);
			verifica("Existe aresta 3->1", grafo.existeAresta(3,1), true);
			verifica("Existe aresta 4->3", grafo.existeAresta(4,3), true);
			verifica("Existe aresta 5->5", grafo.existeAresta(5,5), true);
			
			int arestasExistentes = 0;
			for(int u = 0; u<grafo.numVertices(); u++){
				for(int v = u; v<grafo.numVertices(); v++){
					if(grafo.existeAresta(u,v)){
						arestasExistentes++;
					}
				}
			}
			verifica("Arestas existentes",arestasExistentes,8);
			
			verifica("Grau do vertice 0", grafo.grau(0), 2);
			verifica("Grau do vertice 1", grafo.grau(1), 3);
			verifica("Grau do vertice 2", grafo.grau(2), 2);
			verifica("Grau do vertice 3", grafo.grau(3), 3);
			verifica("Grau do vertice 4", grafo.grau(4), 3);
			verifica("Grau do vertice 5", grafo.grau(5), 2);
			
			List<int> cobertura = Coberturas.vertices(grafo);
			Console.Write("Cobertura de vertices: ");
			foreach(int v in cobertura){
				Console.Write("{0} ", v);
			}
			Console.WriteLine();
			
			List<int> conjIndependente = Conjuntos.independente(grafo);
			Console.Write("Conjunto independente: ");
			foreach(int v in conjIndependente){
				Console.Write("{0} ", v);
			}
			Console.WriteLine();
			
			Console.WriteLine("[Concluido MatrizGrafo]");
			Console.WriteLine();
		}
		
		public static void testaListaGrafo(){
			Console.WriteLine("[Testando ListaGrafo]");
			Grafo grafo = new ListaGrafo(6);
			grafo.adicionaAresta(0,1);
			grafo.adicionaAresta(0,3);
			grafo.adicionaAresta(1,4);
			grafo.adicionaAresta(2,4);
			grafo.adicionaAresta(2,5);
			grafo.adicionaAresta(3,1);
			grafo.adicionaAresta(4,3);
			grafo.adicionaAresta(5,5);
			
			verifica("Numero vertices", grafo.numVertices(), 6);
			verifica("Numero arestas", grafo.numArestas(), 8);
			
			verifica("Existe aresta 0->1", grafo.existeAresta(0,1), true);
			verifica("Existe aresta 0->3", grafo.existeAresta(0,3), true);
			verifica("Existe aresta 1->4", grafo.existeAresta(1,4), true);
			verifica("Existe aresta 2->4", grafo.existeAresta(2,4), true);
			verifica("Existe aresta 2->5", grafo.existeAresta(2,5), true);
			verifica("Existe aresta 3->1", grafo.existeAresta(3,1), true);
			verifica("Existe aresta 4->3", grafo.existeAresta(4,3), true);
			verifica("Existe aresta 5->5", grafo.existeAresta(5,5), true);
			
			int arestasExistentes = 0;
			for(int u = 0; u<grafo.numVertices(); u++){
				for(int v = u; v<grafo.numVertices(); v++){
					if(grafo.existeAresta(u,v)){
						arestasExistentes++;
					}
				}
			}
			verifica("Arestas existentes",arestasExistentes,8);
			
			verifica("Grau do vertice 0", grafo.grau(0), 2);
			verifica("Grau do vertice 1", grafo.grau(1), 3);
			verifica("Grau do vertice 2", grafo.grau(2), 2);
			verifica("Grau do vertice 3", grafo.grau(3), 3);
			verifica("Grau do vertice 4", grafo.grau(4), 3);
			verifica("Grau do vertice 5", grafo.grau(5), 2);
			
			List<int> cobertura = Coberturas.vertices(grafo);
			Console.Write("Cobertura de vertices: ");
			foreach(int v in cobertura){
				Console.Write("{0} ", v);
			}
			Console.WriteLine();
			
			List<int> conjIndependente = Conjuntos.independente(grafo);
			Console.Write("Conjunto independente: ");
			foreach(int v in conjIndependente){
				Console.Write("{0} ", v);
			}
			Console.WriteLine();
			
			Console.WriteLine("[Concluido ListaGrafo]");
			Console.WriteLine();
		}

		public static void Main(string[] args)
		{
			testaMatrizGrafo();
			testaListaGrafo();
		}
	}
}
