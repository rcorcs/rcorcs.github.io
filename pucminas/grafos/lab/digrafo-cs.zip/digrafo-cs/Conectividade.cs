/*
 * Disciplina: Algoritmos em grafos
 * Professor: Rodrigo Caetano Rocha
 * Topico: Estruturas de Dados de Digrafos.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Trabalho_Pratico_I
{

	public class Conectividade {
		
		public static boolean fortementeConectado(Digrafo g){
			//FAZER
			return false;
		}

	}
}

}
