/*
 * Disciplina: Algoritmos em grafos
 * Professor: Rodrigo Caetano Rocha
 * Topico: Estruturas de Dados de Digrafos.
 */

public class Conectividade {
	
	public static boolean fortementeConectado(Digrafo g){
		//FAZER
		return false;
	}

}