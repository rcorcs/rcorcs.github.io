
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_FILE_NAME 1024
#define MAX_WORD 1024

int main(int argc, char **argv){
	char *searchWord = argv[1];

	char fileName[MAX_FILE_NAME];
	char word[MAX_WORD];

	printf("Searching: %s\n", searchWord);

	int count = 0;
	for(int id = 0; id<5; id++){
		sprintf(fileName, "input%d.txt", id);
	
		FILE *fd = fopen(fileName,"r");

		while(fscanf(fd,"%s",word)==1){
			if(!strcmp(word,searchWord)){
				count++;
			}
		}

		fclose(fd);		
	}
	printf("Found: %d\n", count);

	return 0;
}
